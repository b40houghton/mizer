require(['vendor/jquery', 'vendor/modernizr'], function($){


    dc.breakpoints = {
        "mobile": 767,
        "tablet":1024,
        "desktop":1280,
        "current":"desktop"
    }

	//SVG's Polyfill
	require(['vendor/svg4everybody.ie8.min']);
	
    require(['lib/onload','lib/breakpoints','lib/utilities','lib/navigation', 'lib/fancyFooter']);

});